# IST ATC
Web tabanlı, mobil uyumlu ATC oyunu prototipi.

- Default airport: Istanbul Airport (LTFM)
- Radar üzerinde hareket eden trafik
- Klavye ile gerçek komut mantığı
- Mobilde autocomplete / dokunmatik command bar
- Serbest irtifa girişi: FL010, FL100, FL180 vb.
- DESCEND / CLIMB / HDG / SPD / DCT komutları
- Basit skor ve command log

Kullanım: index.html dosyasını tarayıcıda aç.
